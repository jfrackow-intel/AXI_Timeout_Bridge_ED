/*
 * printf_8hex_dec.c
 *
 *  Created on: Sep 23, 2022
 *      Author: jfrackow
 *
 *      %x - modified to print all 8 chars of the hex value
 *      %d - added routine for decimals
 *      	 fixed bug of decimal 0 value
 */

#include <stdarg.h>
#include <sys/alt_stdio.h>

void printf_8hex_dec(const char* fmt, ... )
{
	va_list args;
	va_start(args, fmt);
    const char *w;
    char c;

    /* Process format string. */
    w = fmt;
    while ((c = *w++) != 0)
    {
        /* If not a format escape character, just print  */
        /* character.  Otherwise, process format string. */
        if (c != '%')
        {
            alt_putchar(c);
        }
        else
        {
            /* Get format character.  If none     */
            /* available, processing is complete. */
            if ((c = *w++) != 0)
            {
                if (c == '%')
                {
                    /* Process "%" escape sequence. */
                    alt_putchar(c);
                }
                else if (c == 'x')
                {
                    /* Process hexadecimal number format. */
                    unsigned long v = va_arg(args, unsigned long);
                    unsigned long digit;
                    int digit_shift;
                    unsigned int nr_of_0;

                    /* If the number value is zero, just print and continue. */
                    if (v == 0)
                    {
                    	for(unsigned int i=0; i<8 ;i++) alt_putchar('0');
                        continue;
                    }

                    /* Find first non-zero digit. */
                    digit_shift = 28;
                    while (!(v & (0xF << digit_shift)))
                        digit_shift -= 4;

                    /* Print leading zeros */
                    nr_of_0 = 7 - (unsigned int)(digit_shift>>2);
                    for(unsigned int i=0; i<nr_of_0 ;i++) alt_putchar('0');

                    /* Print digits. */
                    for (; digit_shift >= 0; digit_shift -= 4)
                    {
                        digit = (v & (0xF << digit_shift)) >> digit_shift;
                        if (digit <= 9)
                            c = '0' + digit;
                        else
                            c = 'a' + digit - 10;
                        alt_putchar(c);
                    }
                } else if(c == 'd')
                {
                	unsigned long N = va_arg(args, unsigned long);
                	unsigned long m;
                	int digit = 0;
                	char arr[20];
                	char arr1[20];
                	int index = 0;
                	int i;

                	if(N==0)
                	{
                		alt_putchar('0');
                		continue;
                	}

                	m = N;
                	// Count digits in number N
                    while(m)
                    {
                        // Increment number of digits
                        digit++;

                        // Truncate the last
                        // digit from the number
                        m /= 10;
                    }

                    // Separating integer into digits and
                    // accommodate it to character array
                    while(N)
                    {
                    	// Separate last digit from
                    	// the number and add ASCII
                    	// value of character '0' is 48
                    	arr1[++index] = N % 10 + '0';

                        // Truncate the last
                        // digit from the number
                    	N /= 10;
                    }

                    // Reverse the array for result
                    for(i=0; i<index; i++)
                    {
                    	arr[i] = arr1[index - i];
                    }

                    // Char array truncate by null
                    arr[i] = '\0';

                    // Printout the result
                    alt_putstr(arr);

                }
            }
            else
            {
                break;
            }
        }
    }
    va_end(args);
}
