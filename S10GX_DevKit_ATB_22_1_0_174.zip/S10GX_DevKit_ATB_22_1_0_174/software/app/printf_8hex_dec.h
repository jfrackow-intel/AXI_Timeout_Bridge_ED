/*
 * printf_8hex_dec.h
 *
 *  Created on: Sep 26, 2022
 *      Author: jfrackow
 */

#ifndef PRINTF_8HEX_DEC_H_
#define PRINTF_8HEX_DEC_H_


void printf_8hex_dec(const char* fmt, ... );


#endif /* PRINTF_8HEX_DEC_H_ */
